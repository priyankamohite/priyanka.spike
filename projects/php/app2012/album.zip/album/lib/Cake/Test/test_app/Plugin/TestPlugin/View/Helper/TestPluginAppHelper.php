<?php
class TestPluginAppHelper extends AppHelper {

}
